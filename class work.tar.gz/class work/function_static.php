<?php
/**
 * Created by PhpStorm.
 * User: lict
 * Date: 1/23/15
 * Time: 9:13 AM
 */
myTest();
myTest();
myTest();


function myTest(){


      static $number=6;
    echo "<br>";
    echo $number;
    $number++;



}





?>